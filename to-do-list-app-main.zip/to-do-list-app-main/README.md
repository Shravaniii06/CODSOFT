# To-Do List App

A simple and clean To-Do List web app built with HTML, CSS, and JavaScript. Users can add tasks, mark them as completed, and delete them easily. The interface is responsive and user-friendly.

### Features

* Add new tasks
* Mark tasks as completed
* Delete tasks
* Data saved in browser localStorage
* Fully responsive UI

### Demo

Live Preview:
https://shravaniii06.github.io/to-do-list-app/

### Tech Stack

* HTML
* CSS
* JavaScript
